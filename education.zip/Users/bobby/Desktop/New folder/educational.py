import zipfile
import os

# Set the directory path
import os

# Get the current working directory
cwd = os.getcwd()
print(cwd)

# Get a list of all the file paths in the directory
file_paths = []
for root, dirs, files in os.walk(cwd):
    for file in files:
        file_paths.append(os.path.join(root, file))

# Zip the files
with zipfile.ZipFile('education.zip', 'w') as zip:
    for file in file_paths:
        zip.write(file)

print('All files zipped successfully!')
